const images = [
    {
        id: 1,
        src:
            "https://img-cf.kurly.com/banner/main/pc/img/f607797b-c11f-45d8-919b-68a7d2d4581b",
        alt: "The world"
    },
    {
        id: 2,
        src:
            "https://img-cf.kurly.com/banner/main/pc/img/ab2389bf-5bef-4886-b1f8-8696ddd309b3",
        alt: "Train"
    },
    {
        id: 3,
        src:
            "https://img-cf.kurly.com/banner/main/pc/img/31df528e-ad56-40d6-921e-c6d129f9ac20",
        alt: "Laptop"
    }
];
export default images;

